/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 54df7406bd33851eb5fdde48362754bfd71e0500"
		" build by rkammerer@aperol, 2016-12-23 15:03:04";
}
