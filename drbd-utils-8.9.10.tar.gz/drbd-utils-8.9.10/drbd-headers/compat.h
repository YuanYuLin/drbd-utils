/* dummy compat.h to satisfy kernel-side include linux/genl_magic_struct.h */

